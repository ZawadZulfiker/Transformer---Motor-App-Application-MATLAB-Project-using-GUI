function varargout = Magnetization_Curve_Value(varargin)
% MAGNETIZATION_CURVE_VALUE MATLAB code for Magnetization_Curve_Value.fig
%      MAGNETIZATION_CURVE_VALUE, by itself, creates a new MAGNETIZATION_CURVE_VALUE or raises the existing
%      singleton*.
%
%      H = MAGNETIZATION_CURVE_VALUE returns the handle to a new MAGNETIZATION_CURVE_VALUE or the handle to
%      the existing singleton*.
%
%      MAGNETIZATION_CURVE_VALUE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAGNETIZATION_CURVE_VALUE.M with the given input arguments.
%
%      MAGNETIZATION_CURVE_VALUE('Property','Value',...) creates a new MAGNETIZATION_CURVE_VALUE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Magnetization_Curve_Value_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Magnetization_Curve_Value_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Magnetization_Curve_Value

% Last Modified by GUIDE v2.5 17-Aug-2019 01:43:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @Magnetization_Curve_Value_OpeningFcn, ...
    'gui_OutputFcn',  @Magnetization_Curve_Value_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Magnetization_Curve_Value is made visible.
function Magnetization_Curve_Value_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Magnetization_Curve_Value (see VARARGIN)

% Choose default command line output for Magnetization_Curve_Value
handles.output = hObject;
some_t=getappdata(0,'nam_e');
set(handles.text2,'String',['Hey ' some_t ', please give the information we need here:']);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Magnetization_Curve_Value wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Magnetization_Curve_Value_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in loadDat.
function loadDat_Callback(hObject, eventdata, handles)
% hObject    handle to loadDat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename pathname]=uigetfile('*.mag;*.dat','Pick Your Necessary File:');
datfile=load(filename);
handles.dat=datfile;
guidata(hObject,handles);



function editPV_Callback(hObject, eventdata, handles)
% hObject    handle to editPV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editPV as text
pvtake=str2double(get(hObject,'String'));
setappdata(0,'pvt',pvtake);


% --- Executes during object creation, after setting all properties.
function editPV_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editPV (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editNP_Callback(hObject, eventdata, handles)
% hObject    handle to editNP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editNP as text
nptake=str2double(get(hObject,'String'));
setappdata(0,'npt',nptake);


% --- Executes during object creation, after setting all properties.
function editNP_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editNP (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function editCyc_Callback(hObject, eventdata, handles)
% hObject    handle to editCyc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editCyc as text
cyctake=str2double(get(hObject,'String'));
setappdata(0,'cyct',cyctake);


% --- Executes during object creation, after setting all properties.
function editCyc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editCyc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
if isfield(handles,'dat')
    setappdata(0,'magct',handles.dat);
end
graph_im



function editFrequ_Callback(hObject, eventdata, handles)
% hObject    handle to editFrequ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of editFrequ as text
freqtake=str2double(get(hObject,'String'));
setappdata(0,'freqt',freqtake);


% --- Executes during object creation, after setting all properties.
function editFrequ_CreateFcn(hObject, eventdata, handles)
% hObject    handle to editFrequ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
