function varargout = transformer(varargin)
% TRANSFORMER MATLAB code for transformer.fig
%      TRANSFORMER, by itself, creates a new TRANSFORMER or raises the existing
%      singleton*.
%
%      H = TRANSFORMER returns the handle to a new TRANSFORMER or the handle to
%      the existing singleton*.
%
%      TRANSFORMER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TRANSFORMER.M with the given input arguments.
%
%      TRANSFORMER('Property','Value',...) creates a new TRANSFORMER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before transformer_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to transformer_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help transformer

% Last Modified by GUIDE v2.5 17-Sep-2019 17:39:06

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @transformer_OpeningFcn, ...
                   'gui_OutputFcn',  @transformer_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before transformer is made visible.
function transformer_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to transformer (see VARARGIN)

% Choose default command line output for transformer
handles.output = hObject;
some_t=getappdata(0,'nam_e');
set(handles.text2,'String',['Hey ' some_t ', please tap on which tranformer operation you want to do:']);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes transformer wait for user response (see UIRESUME)
% uiwait(handles.xformer);


% --- Outputs from this function are returned to the command line.
function varargout = transformer_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in vr.
function vr_Callback(hObject, eventdata, handles)
% hObject    handle to vr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
vr_option


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in pd.
function pd_Callback(hObject, eventdata, handles)
% hObject    handle to pd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
phase_option



% --- Executes on button press in im.
function im_Callback(hObject, eventdata, handles)
% hObject    handle to im (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
Magnetization_Curve_Value


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
auto_trans


% --- Executes on button press in pushbutton6.
function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
trans_pow
