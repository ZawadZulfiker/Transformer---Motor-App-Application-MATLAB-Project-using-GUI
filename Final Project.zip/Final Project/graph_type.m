function varargout = graph_type(varargin)
% GRAPH_TYPE MATLAB code for graph_type.fig
%      GRAPH_TYPE, by itself, creates a new GRAPH_TYPE or raises the existing
%      singleton*.
%
%      H = GRAPH_TYPE returns the handle to a new GRAPH_TYPE or the handle to
%      the existing singleton*.
%
%      GRAPH_TYPE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GRAPH_TYPE.M with the given input arguments.
%
%      GRAPH_TYPE('Property','Value',...) creates a new GRAPH_TYPE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before graph_type_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to graph_type_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help graph_type

% Last Modified by GUIDE v2.5 28-Aug-2019 00:27:21

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @graph_type_OpeningFcn, ...
                   'gui_OutputFcn',  @graph_type_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before graph_type is made visible.
function graph_type_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to graph_type (see VARARGIN)

% Choose default command line output for graph_type
handles.output = hObject;
some_t=getappdata(0,'nam_e');
set(handles.text2,'String',['Hey ' some_t ', please tap on which type of graph you want to see:']);
axes(handles.axes1)
imshow('vector_phs.jpg');
axes(handles.axes2)
imshow('polar_phs.png');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes graph_type wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = graph_type_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vector_phase


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
polar_phase
