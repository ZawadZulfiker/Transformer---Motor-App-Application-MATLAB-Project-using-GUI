function varargout = graph_vr(varargin)
% GRAPH_VR MATLAB code for graph_vr.fig
%      GRAPH_VR, by itself, creates a new GRAPH_VR or raises the existing
%      singleton*.
%
%      H = GRAPH_VR returns the handle to a new GRAPH_VR or the handle to
%      the existing singleton*.
%
%      GRAPH_VR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in GRAPH_VR.M with the given input arguments.
%
%      GRAPH_VR('Property','Value',...) creates a new GRAPH_VR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before graph_vr_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to graph_vr_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help graph_vr

% Last Modified by GUIDE v2.5 27-Aug-2019 20:54:25

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @graph_vr_OpeningFcn, ...
                   'gui_OutputFcn',  @graph_vr_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before graph_vr is made visible.
function graph_vr_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to graph_vr (see VARARGIN)
clc
plot(0,0);
% Choose default command line output for vr_graph
handles.output = hObject;
vs=getappdata(0,'vst');
pow=getappdata(0,'powt');
rated_current=pow/vs;
amps=linspace(0,rated_current,11);
req=getappdata(0,'reqt');
xeq=getappdata(0,'xeqt');
pf=getappdata(0,'pft');
pf_real=pf;
pf_img=sin(acos(pf));
pfttxt=getappdata(0,'pftyp');
pft=get(pfttxt,'String');
if strcmp(pft,'leading')==1
    pfval=pf_real+pf_img*i;
elseif strcmp(pft,'lagging')==1
    pfval=pf_real-pf_img*i;
elseif strcmp(pft,'unity')==1
    pfval=pf;
end
is=amps.*pfval;
vpa=vs+(req+j*xeq).*is;
vr=(abs(vpa)-vs)./vs.*100;
plot(amps,vr);
grid on;
title('Voltage Regulation Versus Load');
xlabel(['Given Loads at ' num2str(pf) ' power factor ' pft]);
ylabel(['Voltage Regulation_{%}']);
grid on;
some_t=getappdata(0,'nam_e');
myimg=imread('succeed.jpg');
msgbox(['Congratulation! Dear ' some_t '. This is your expected graph!'],'You Got Your Graph','custom',myimg);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes graph_vr wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = graph_vr_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
