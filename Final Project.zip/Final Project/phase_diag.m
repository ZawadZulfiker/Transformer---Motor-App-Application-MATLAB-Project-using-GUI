function phase_diag(Z)
hold on
m = 1.2 * max([abs(real(Z)) abs(imag(Z))]);
quiver(0*real(Z),0*imag(Z),real(Z),imag(Z));
plot([-m m],[0 0])
plot([0 0],[-m m])
axis([-m,m,-m,m], 'square')
end