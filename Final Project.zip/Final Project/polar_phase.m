function varargout = polar_phase(varargin)
% POLAR_PHASE MATLAB code for polar_phase.fig
%      POLAR_PHASE, by itself, creates a new POLAR_PHASE or raises the existing
%      singleton*.
%
%      H = POLAR_PHASE returns the handle to a new POLAR_PHASE or the handle to
%      the existing singleton*.
%
%      POLAR_PHASE('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in POLAR_PHASE.M with the given input arguments.
%
%      POLAR_PHASE('Property','Value',...) creates a new POLAR_PHASE or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before polar_phase_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to polar_phase_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help polar_phase

% Last Modified by GUIDE v2.5 28-Aug-2019 00:39:27

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @polar_phase_OpeningFcn, ...
                   'gui_OutputFcn',  @polar_phase_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before polar_phase is made visible.
function polar_phase_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to polar_phase (see VARARGIN)

% Choose default command line output for polar_phase
handles.output = hObject;
vs=getappdata(0,'vst');
pow=getappdata(0,'powt');
rated_current=pow/vs;
req=getappdata(0,'reqt');
xeq=getappdata(0,'xeqt');
pf=getappdata(0,'pft');
pfttxt=getappdata(0,'pftyp');
pft=get(pfttxt,'String');
theta=acos(pf);
if strcmp(pft,'leading')==1
    is=rated_current*exp(i*theta);
elseif strcmp(pft,'lagging')==1
    is=rated_current*exp(-i*theta);
elseif strcmp(pft,'unity')==1
    is=rated_current;
end
reqis=req*is;
xeqis=j*xeq*is;
vpa=vs+(req+j*xeq).*is;
phase_diag([vs is reqis xeqis vpa]);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes polar_phase wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = polar_phase_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
