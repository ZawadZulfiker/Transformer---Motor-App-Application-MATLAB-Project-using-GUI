function p=open_circuit(voc,ioc,poc)
thetaoc=acos(poc/(voc*ioc));
ye=(ioc/voc)*exp(-i*thetaoc);
rc=1./(real(ye));
xm=-1./(imag(ye));
p=[rc xm];
end