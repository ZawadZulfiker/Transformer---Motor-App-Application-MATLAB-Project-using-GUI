function varargout = phase_fig(varargin)
% PHASE_FIG MATLAB code for phase_fig.fig
%      PHASE_FIG, by itself, creates a new PHASE_FIG or raises the existing
%      singleton*.
%
%      H = PHASE_FIG returns the handle to a new PHASE_FIG or the handle to
%      the existing singleton*.
%
%      PHASE_FIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PHASE_FIG.M with the given input arguments.
%
%      PHASE_FIG('Property','Value',...) creates a new PHASE_FIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before phase_fig_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to phase_fig_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help phase_fig

% Last Modified by GUIDE v2.5 15-Sep-2019 20:43:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @phase_fig_OpeningFcn, ...
                   'gui_OutputFcn',  @phase_fig_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before phase_fig is made visible.
function phase_fig_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to phase_fig (see VARARGIN)
clc
plot(0,0);
% Choose default command line output for vector_phase
handles.output = hObject;
vs=getappdata(0,'vst');
pow=getappdata(0,'powt');
rated_current=pow/vs;
req=getappdata(0,'reqt');
xeq=getappdata(0,'xeqt');
pf=getappdata(0,'pft');
pfttxt=getappdata(0,'pftyp');
pft=get(pfttxt,'String');
theta=acos(pf);
if strcmp(pft,'leading')==1
    is=rated_current*exp(i*theta);
elseif strcmp(pft,'lagging')==1
    is=rated_current*exp(-i*theta);
elseif strcmp(pft,'unity')==1
    is=rated_current;
end
reqis=req*is;
xeqis=j*xeq*is;
vpa=vs+(req+j*xeq).*is;
vpa_val=abs(vpa);
vpa_ang=rad2deg(angle(vpa));
if strcmp(pft,'leading')==1
    imshow('leading_power_factor.jpg');
elseif strcmp(pft,'lagging')==1
    imshow('lagging_power_factor.jpg');
    theta=-theta;
elseif strcmp(pft,'unity')==1
    imshow('unity_power_factor.jpg');
end
title(['Transformer Phasor Diagram,values: I_{s}=' num2str(rated_current) ', \theta_{s}=' num2str(rad2deg(theta)) '\circ, R_{eq}I_{s}=' num2str(abs(reqis)) ', jX_{eq}I_{s}=' num2str(abs(xeqis)) ', \theta_{IS}=' num2str(rad2deg(angle(xeqis))) '\circ, V_{s}=' num2str(vs) ', V_{p}/a=' num2str(vpa_val) ', \theta_{all}=' num2str(vpa_ang) '\circ'],'Color','w');
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes phase_fig wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = phase_fig_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;
