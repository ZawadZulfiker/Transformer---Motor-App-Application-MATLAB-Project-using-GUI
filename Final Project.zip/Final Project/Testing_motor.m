function varargout = Testing_motor(varargin)
% TESTING_MOTOR MATLAB code for Testing_motor.fig
%      TESTING_MOTOR, by itself, creates a new TESTING_MOTOR or raises the existing
%      singleton*.
%
%      H = TESTING_MOTOR returns the handle to a new TESTING_MOTOR or the handle to
%      the existing singleton*.
%
%      TESTING_MOTOR('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TESTING_MOTOR.M with the given input arguments.
%
%      TESTING_MOTOR('Property','Value',...) creates a new TESTING_MOTOR or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before Testing_motor_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to Testing_motor_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help Testing_motor

% Last Modified by GUIDE v2.5 27-Aug-2019 18:14:20

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @Testing_motor_OpeningFcn, ...
                   'gui_OutputFcn',  @Testing_motor_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before Testing_motor is made visible.
function Testing_motor_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to Testing_motor (see VARARGIN)
clc;
% Choose default command line output for Testing_motor
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes Testing_motor wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = Testing_motor_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.

function pushbutton3_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.r1,'String','');
set(handles.x1e,'String','');
set(handles.r2,'String','');
set(handles.x2e,'String','');
set(handles.xm,'String','');
set(handles.vl,'String','');
set(handles.f,'String','');
set(handles.p,'String','');
set(handles.pin,'String','');
set(handles.pscl,'String','');
set(handles.prot,'String','');
set(handles.pag,'String','');
set(handles.pconv,'String','');
set(handles.vdc,'String','');
set(handles.idc,'String','');
set(handles.vnl,'String','');
set(handles.inl1,'String','');
set(handles.inl2,'String','');
set(handles.inl3,'String','');
set(handles.fnl,'String','');
set(handles.pnl,'String','');
set(handles.vlr,'String','');
set(handles.ilr1,'String','');
set(handles.ilr2,'String','');
set(handles.plr,'String','');
set(handles.flr,'String','');
set(handles.ilr3,'String','');
axes(handles.axes1);
cla reset;
axes(handles.axes2);
cla reset;
axes(handles.axes3);
cla reset;

set(handles.wrm,'Value',0);
set(handles.da,'Value',0);
set(handles.db,'Value',0);
set(handles.dc,'Value',0);
set(handles.dd,'Value',0);
set(handles.yc,'Value',0);
set(handles.dl,'Value',0);


function pin_Callback(hObject, eventdata, handles)
% hObject    handle to pin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pin as text
%        str2double(get(hObject,'String')) returns contents of pin as a double


% --- Executes during object creation, after setting all properties.
function pin_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pscl_Callback(hObject, eventdata, handles)
% hObject    handle to pscl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pscl as text
%        str2double(get(hObject,'String')) returns contents of pscl as a double


% --- Executes during object creation, after setting all properties.
function pscl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pscl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function prot_Callback(hObject, eventdata, handles)
% hObject    handle to prot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of prot as text
%        str2double(get(hObject,'String')) returns contents of prot as a double


% --- Executes during object creation, after setting all properties.
function prot_CreateFcn(hObject, eventdata, handles)
% hObject    handle to prot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pconv_Callback(hObject, eventdata, handles)
% hObject    handle to pconv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pconv as text
%        str2double(get(hObject,'String')) returns contents of pconv as a double


% --- Executes during object creation, after setting all properties.
function pconv_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pconv (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pag_Callback(hObject, eventdata, handles)
% hObject    handle to pag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pag as text
%        str2double(get(hObject,'String')) returns contents of pag as a double


% --- Executes during object creation, after setting all properties.
function pag_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pag (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function r1_Callback(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of r1 as text
%        str2double(get(hObject,'String')) returns contents of r1 as a double


% --- Executes during object creation, after setting all properties.
function r1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x1e_Callback(hObject, eventdata, handles)
% hObject    handle to x1e (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x1e as text
%        str2double(get(hObject,'String')) returns contents of x1e as a double


% --- Executes during object creation, after setting all properties.
function x1e_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x1e (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function xm_Callback(hObject, eventdata, handles)
% hObject    handle to xm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of xm as text
%        str2double(get(hObject,'String')) returns contents of xm as a double


% --- Executes during object creation, after setting all properties.
function xm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function r2_Callback(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of r2 as text
%        str2double(get(hObject,'String')) returns contents of r2 as a double


% --- Executes during object creation, after setting all properties.
function r2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x2e_Callback(hObject, eventdata, handles)
% hObject    handle to x2e (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x2e as text
%        str2double(get(hObject,'String')) returns contents of x2e as a double


% --- Executes during object creation, after setting all properties.
function x2e_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x2e (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vlr_Callback(hObject, eventdata, handles)
% hObject    handle to vlr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vlr as text
%        str2double(get(hObject,'String')) returns contents of vlr as a double


% --- Executes during object creation, after setting all properties.
function vlr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vlr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ilr1_Callback(hObject, eventdata, handles)
% hObject    handle to ilr1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ilr1 as text
%        str2double(get(hObject,'String')) returns contents of ilr1 as a double


% --- Executes during object creation, after setting all properties.
function ilr1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ilr1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ilr2_Callback(hObject, eventdata, handles)
% hObject    handle to ilr2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ilr2 as text
%        str2double(get(hObject,'String')) returns contents of ilr2 as a double


% --- Executes during object creation, after setting all properties.
function ilr2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ilr2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function ilr3_Callback(hObject, eventdata, handles)
% hObject    handle to ilr3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ilr3 as text
%        str2double(get(hObject,'String')) returns contents of ilr3 as a double


% --- Executes during object creation, after setting all properties.
function ilr3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ilr3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function flr_Callback(hObject, eventdata, handles)
% hObject    handle to flr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of flr as text
%        str2double(get(hObject,'String')) returns contents of flr as a double


% --- Executes during object creation, after setting all properties.
function flr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to flr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function plr_Callback(hObject, eventdata, handles)
% hObject    handle to plr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of plr as text
%        str2double(get(hObject,'String')) returns contents of plr as a double


% --- Executes during object creation, after setting all properties.
function plr_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plr (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vl_Callback(hObject, eventdata, handles)
% hObject    handle to vl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vl as text
%        str2double(get(hObject,'String')) returns contents of vl as a double


% --- Executes during object creation, after setting all properties.
function vl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function f_Callback(hObject, eventdata, handles)
% hObject    handle to f (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of f as text
%        str2double(get(hObject,'String')) returns contents of f as a double


% --- Executes during object creation, after setting all properties.
function f_CreateFcn(hObject, eventdata, handles)
% hObject    handle to f (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function p_Callback(hObject, eventdata, handles)
% hObject    handle to p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p as text
%        str2double(get(hObject,'String')) returns contents of p as a double


% --- Executes during object creation, after setting all properties.
function p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vnl_Callback(hObject, eventdata, handles)
% hObject    handle to vnl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vnl as text
%        str2double(get(hObject,'String')) returns contents of vnl as a double


% --- Executes during object creation, after setting all properties.
function vnl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vnl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function inl1_Callback(hObject, eventdata, handles)
% hObject    handle to inl1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of inl1 as text
%        str2double(get(hObject,'String')) returns contents of inl1 as a double


% --- Executes during object creation, after setting all properties.
function inl1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inl1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function inl2_Callback(hObject, eventdata, handles)
% hObject    handle to inl2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of inl2 as text
%        str2double(get(hObject,'String')) returns contents of inl2 as a double


% --- Executes during object creation, after setting all properties.
function inl2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inl2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function inl3_Callback(hObject, eventdata, handles)
% hObject    handle to inl3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of inl3 as text
%        str2double(get(hObject,'String')) returns contents of inl3 as a double


% --- Executes during object creation, after setting all properties.
function inl3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to inl3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function fnl_Callback(hObject, eventdata, handles)
% hObject    handle to fnl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of fnl as text
%        str2double(get(hObject,'String')) returns contents of fnl as a double


% --- Executes during object creation, after setting all properties.
function fnl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to fnl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pnl_Callback(hObject, eventdata, handles)
% hObject    handle to pnl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pnl as text
%        str2double(get(hObject,'String')) returns contents of pnl as a double


% --- Executes during object creation, after setting all properties.
function pnl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pnl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vdc_Callback(hObject, eventdata, handles)
% hObject    handle to vdc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vdc as text
%        str2double(get(hObject,'String')) returns contents of vdc as a double


% --- Executes during object creation, after setting all properties.
function vdc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vdc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function idc_Callback(hObject, eventdata, handles)
% hObject    handle to idc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of idc as text
%        str2double(get(hObject,'String')) returns contents of idc as a double


% --- Executes during object creation, after setting all properties.
function idc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to idc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton4.


function wrm_Callback(hObject, eventdata, handles)
% hObject    handle to wrm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of wrm


% --- Executes on button press in radiobutton9.
if(get(handles.wrm,'Value')==1)
    set(handles.da,'Value',0);
    set(handles.db,'Value',0);
    set(handles.dc,'Value',0);
    set(handles.dd,'Value',0);
    
end
if(get(handles.wrm,'Value')==0)
    set(handles.r1,'String','');
    set(handles.x1e,'String','');
    set(handles.r2,'String','');
    set(handles.x2e,'String','');
    set(handles.xm,'String','');
    set(handles.pin,'String','');
    set(handles.pscl,'String','');
    set(handles.prot,'String','');
    set(handles.pag,'String','');
    set(handles.pconv,'String','');
    axes(handles.axes1);
    cla reset;
    axes(handles.axes2);
    cla reset;
    axes(handles.axes3);
    cla reset;
end


function da_Callback(hObject, eventdata, handles)
% hObject    handle to da (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of da


% --- Executes on button press in db.

if(get(handles.da,'Value')==1)
    set(handles.wrm,'Value',0);
    set(handles.db,'Value',0);
    set(handles.dc,'Value',0);
    set(handles.dd,'Value',0);
end
if(get(handles.da,'Value')==0)
    set(handles.r1,'String','');
    set(handles.x1e,'String','');
    set(handles.r2,'String','');
    set(handles.x2e,'String','');
    set(handles.xm,'String','');
    set(handles.pin,'String','');
    set(handles.pscl,'String','');
    set(handles.prot,'String','');
    set(handles.pag,'String','');
    set(handles.pconv,'String','');
    axes(handles.axes1);
    cla reset;
    axes(handles.axes2);
    cla reset;
    axes(handles.axes3);
    cla reset;
end


function db_Callback(hObject, eventdata, handles)
% hObject    handle to db (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of db


% --- Executes on button press in dc.

if(get(handles.db,'Value')==1)
    set(handles.da,'Value',0);
    set(handles.wrm,'Value',0);
    set(handles.dc,'Value',0);
    set(handles.dd,'Value',0);
end
if(get(handles.db,'Value')==0)
    set(handles.r1,'String','');
    set(handles.x1e,'String','');
    set(handles.r2,'String','');
    set(handles.x2e,'String','');
    set(handles.xm,'String','');
    set(handles.pin,'String','');
    set(handles.pscl,'String','');
    set(handles.prot,'String','');
    set(handles.pag,'String','');
    set(handles.pconv,'String','');
    axes(handles.axes1);
    cla reset;
    axes(handles.axes2);
    cla reset;
    axes(handles.axes3);
    cla reset;
end

function dc_Callback(hObject, eventdata, handles)
% hObject    handle to dc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dc


% --- Executes on button press in dd.
if(get(handles.dc,'Value')==1)
    set(handles.da,'Value',0);
    set(handles.db,'Value',0);
    set(handles.wrm,'Value',0);
    set(handles.dd,'Value',0);
end
if(get(handles.dc,'Value')==0)
    set(handles.r1,'String','');
    set(handles.x1e,'String','');
    set(handles.r2,'String','');
    set(handles.x2e,'String','');
    set(handles.xm,'String','');
    set(handles.pin,'String','');
    set(handles.pscl,'String','');
    set(handles.prot,'String','');
    set(handles.pag,'String','');
    set(handles.pconv,'String','');
    axes(handles.axes1);
    cla reset;
    axes(handles.axes2);
    cla reset;
    axes(handles.axes3);
    cla reset;
end

function dd_Callback(hObject, eventdata, handles)
% hObject    handle to dd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dd


% --- Executes on button press in pushbutton6.
if(get(handles.dd,'Value')==1)
    set(handles.da,'Value',0);
    set(handles.db,'Value',0);
    set(handles.dc,'Value',0);
    set(handles.wrm,'Value',0);
    
end
if(get(handles.dd,'Value')==0)
    set(handles.r1,'String','');
    set(handles.x1e,'String','');
    set(handles.r2,'String','');
    set(handles.x2e,'String','');
    set(handles.xm,'String','');
    set(handles.pin,'String','');
    set(handles.pscl,'String','');
    set(handles.prot,'String','');
    set(handles.pag,'String','');
    set(handles.pconv,'String','');
    axes(handles.axes1);
    cla reset;
    axes(handles.axes2);
    cla reset;
    axes(handles.axes3);
    cla reset;
end

function pushbutton6_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
vdc=str2double(get(handles.vdc,'String'));
idc=str2double(get(handles.idc,'String'));
vnl=str2double(get(handles.vnl,'String'));
inl1=str2double(get(handles.inl1,'String'));

inl2=str2double(get(handles.inl2,'String'));
inl3=str2double(get(handles.inl3,'String'));
fnl=str2double(get(handles.fnl,'String'));
pnl=str2double(get(handles.pnl,'String'));

vlr=str2double(get(handles.vlr,'String'));
ilr1=str2double(get(handles.ilr1,'String'));
ilr2=str2double(get(handles.ilr2,'String'));
ilr3=str2double(get(handles.ilr3,'String'));
flr=str2double(get(handles.flr,'String'));

plr=str2double(get(handles.plr,'String'));
vl=str2double(get(handles.vl,'String'));
f=str2double(get(handles.f,'String'));
pole=str2double(get(handles.p,'String'));

s=0:0.01:1;
s(1)=0.001;
vp=vl/sqrt(3);

nsync=(120*f)/pole;
wsync=(2*pi*nsync)/60;
nm=(1-s)*nsync;
l=0;
if(get(handles.yc,'Value')==1) 
    r1=vdc/(2*idc);
    set(handles.r1,'String',num2str(r1));
    
    inlavg=(inl1+inl2+inl3)/3;
    vpnl=vnl/sqrt(3);
    znlp=vpnl/inlavg;
    znl=(f/fnl)*znlp;
    
    pscl=3*inlavg^2*r1;
    set(handles.pscl,'String',num2str(pscl));
    
    prot=pnl-pscl;
    set(handles.prot,'String',num2str(prot));
    
    ilravg=(ilr1+ilr2+ilr3)/3;
    zlr=(vlr/sqrt(3))/ilravg;
    rlrp=zlr*cos(acos(plr/(sqrt(3)*vlr*ilravg)));
    r2=rlrp-r1;
    set(handles.r2,'String',num2str(r2));
    
    xlrp=zlr*sin(acos(plr/(sqrt(3)*vlr*ilravg)));
    l=1;
end

if(get(handles.dl,'Value')==1)
    r1=(3*vdc)/(2*idc);
    set(handles.r1,'String',num2str(r1));
    
    inlavg=((inl1+inl2+inl3)/3)/sqrt(3);
    vpnl=vnl;
    znlp=vpnl/inlavg;
    znl=(f/fnl)*znlp;
    
    pscl=3*inlavg^2*r1;
    set(handles.pscl,'String',num2str(pscl));
    
    prot=pnl-pscl;
    set(handles.prot,'String',num2str(prot));
    
    ilravg=((ilr1+ilr2+ilr3)/3)/sqrt(3);
    zlr=(vlr)/ilravg;
    rlrp=zlr*cos(acos(plr/(3*vlr*ilravg)));
    r2=rlrp-r1;
    set(handles.r2,'String',num2str(r2));
    
    xlrp=zlr*sin(acos(plr/(3*vlr*ilravg)));
    l=1;
end

if l==1
    xlr=(f/flr)*xlrp;
    a=1;
    if(get(handles.wrm,'Value')==1)
        
        x1=0.5*xlr;
        x2=0.5*xlr;
        set(handles.x1e,'String',num2str(x1));
        set(handles.x2e,'String',num2str(x2));
        xm=znl-x1;
        set(handles.xm,'String',num2str(xm));
    elseif(get(handles.da,'Value')==1)
        
        x1=0.5*xlr;
        x2=0.5*xlr;
        set(handles.x1e,'String',num2str(x1));
        set(handles.x2e,'String',num2str(x2));
        xm=znl-x1;
        set(handles.xm,'String',num2str(xm));
    elseif(get(handles.db,'Value')==1)
        
        x1=0.4*xlr;
        x2=0.6*xlr;
        set(handles.x1e,'String',num2str(x1));
        set(handles.x2e,'String',num2str(x2));
        xm=znl-x1;
        set(handles.xm,'String',num2str(xm));
        
    elseif(get(handles.dc,'Value')==1)
        x1=0.3*xlr;
        x2=0.7*xlr;
        set(handles.x1e,'String',num2str(x1));
        set(handles.x2e,'String',num2str(x2));
        xm=znl-x1;
        set(handles.xm,'String',num2str(xm));
    elseif(get(handles.dd,'Value')==1)
        x1=0.5*xlr;
        x2=0.5*xlr;
        set(handles.x1e,'String',num2str(x1));
        set(handles.x2e,'String',num2str(x2));
        xm=znl-x1;
        set(handles.xm,'String',num2str(xm));
    else
        a=0;
    end
    if a~=0
        vth=vp*(xm/sqrt(r1^2+(x1+xm)^2));
        zth=(j*xm*(r1+j*x1))/(r1+j*(x1+xm));
        rth=real(zth);
        xth=imag(zth);
        
        t_ind=zeros(1,length(s));
        t_ind(1:end)=(3*vth^2*r2./s(1:end))./(wsync*((rth+r2./s(1:end)).^2+(xth+x2)^2));
        
        axes(handles.axes1);
        plot(nm,t_ind);
        xlabel('Mechanical Speed(rev/min)');
        ylabel('Induced torque(Nm)');
        sm=r2/(sqrt(rth^2+(xth+x2)^2));
        t_indm=(3*vth^2*r2/sm)/(wsync*((rth+r2/sm)^2+(xth+x2)^2));
        wms=(1-sm)*wsync;
        pconv=t_indm*wms;
        pag=pconv/(1-sm);
        prcl=sm*pag;
        set(handles.pconv,'String',num2str(pconv));
        set(handles.pag,'String',num2str(pag));
        set(handles.pin,'String',num2str(prcl));
        im=imread('equivalent_circuit_.JPG');
        axes(handles.axes2);
        imshow(im);
        im=imread('power_flow_diagram_.JPG');
        axes(handles.axes3);
        imshow(im);
    end
end

% --- Executes on button press in yc.
function yc_Callback(hObject, eventdata, handles)
% hObject    handle to yc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of yc


% --- Executes on button press in dl.
if(get(handles.yc,'Value')==1)
    set(handles.dl,'Value',0);
end
if(get(handles.yc,'Value')==0)
    set(handles.r1,'String','');
    set(handles.x1e,'String','');
    set(handles.r2,'String','');
    set(handles.x2e,'String','');
    set(handles.xm,'String','');
    set(handles.pin,'String','');
    set(handles.pscl,'String','');
    set(handles.prot,'String','');
    set(handles.pag,'String','');
    set(handles.pconv,'String','');
    axes(handles.axes1);
    cla reset;
    axes(handles.axes2);
    cla reset;
    axes(handles.axes3);
    cla reset;
end
function dl_Callback(hObject, eventdata, handles)
% hObject    handle to dl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of dl
if(get(handles.dl,'Value')==1)
    set(handles.yc,'Value',0);
end
if(get(handles.dl,'Value')==0)
    set(handles.r1,'String','');
    set(handles.x1e,'String','');
    set(handles.r2,'String','');
    set(handles.x2e,'String','');
    set(handles.xm,'String','');
    set(handles.pin,'String','');
    set(handles.pscl,'String','');
    set(handles.prot,'String','');
    set(handles.pag,'String','');
    set(handles.pconv,'String','');
    axes(handles.axes1);
    cla reset;
    axes(handles.axes2);
    cla reset;
    axes(handles.axes3);
    cla reset;
end
