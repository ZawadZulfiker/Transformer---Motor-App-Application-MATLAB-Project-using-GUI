function varargout = pf_opt(varargin)
% PF_OPT MATLAB code for pf_opt.fig
%      PF_OPT, by itself, creates a new PF_OPT or raises the existing
%      singleton*.
%
%      H = PF_OPT returns the handle to a new PF_OPT or the handle to
%      the existing singleton*.
%
%      PF_OPT('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in PF_OPT.M with the given input arguments.
%
%      PF_OPT('Property','Value',...) creates a new PF_OPT or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before pf_opt_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to pf_opt_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help pf_opt

% Last Modified by GUIDE v2.5 28-Aug-2019 12:59:13

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @pf_opt_OpeningFcn, ...
                   'gui_OutputFcn',  @pf_opt_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before pf_opt is made visible.
function pf_opt_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to pf_opt (see VARARGIN)

% Choose default command line output for pf_opt
handles.output = hObject;
some_t=getappdata(0,'nam_e');
set(handles.text2,'String',['Hey ' some_t ', please tap on which you want to work:']);
% Update handles structure
guidata(hObject, handles);

% UIWAIT makes pf_opt wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = pf_opt_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pfcal


% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
capcal
