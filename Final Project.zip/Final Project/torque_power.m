function varargout = torque_power(varargin)
% TORQUE_POWER MATLAB code for torque_power.fig
%      TORQUE_POWER, by itself, creates a new TORQUE_POWER or raises the existing
%      singleton*.
%
%      H = TORQUE_POWER returns the handle to a new TORQUE_POWER or the handle to
%      the existing singleton*.
%
%      TORQUE_POWER('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TORQUE_POWER.M with the given input arguments.
%
%      TORQUE_POWER('Property','Value',...) creates a new TORQUE_POWER or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before torque_power_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to torque_power_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help torque_power

% Last Modified by GUIDE v2.5 13-Aug-2019 16:16:54

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @torque_power_OpeningFcn, ...
                   'gui_OutputFcn',  @torque_power_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before torque_power is made visible.
function torque_power_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to torque_power (see VARARGIN)
clc;
% Choose default command line output for torque_power
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes torque_power wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = torque_power_OutputFcn(~, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pc.
function pc_Callback(hObject, eventdata, handles)
% hObject    handle to pc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of pc
if(get(handles.pc,'Value')==0);
    axes(handles.axes2);
    cla reset;
end

% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
r1=str2double(get(handles.r1,'String'));
r2=str2double(get(handles.r2,'String'));
x1=str2double(get(handles.x1,'String'));
x2=str2double(get(handles.x2,'String'));

xm=str2double(get(handles.xm,'String'));
vl=str2double(get(handles.vl,'String'));
f=str2double(get(handles.f,'String'));
pole=str2double(get(handles.p,'String'));
pmisc=str2double(get(handles.pmisc,'String'));
pcore=str2double(get(handles.pcore,'String'));
pfric=str2double(get(handles.pfw,'String'));

s=0:0.01:1;
s(1)=0.001;
vp=vl/sqrt(3);

nsync=(120*f)/pole;
wsync=(2*pi*nsync)/60;
nm=(1-s)*nsync;

vth=vp*(xm/sqrt(r1^2+(x1+xm)^2));
zth=(j*xm*(r1+j*x1))/(r1+j*(x1+xm));
rth=real(zth);
xth=imag(zth);
t_ind=zeros(1,length(s));
t_ind(1:end)=(3*vth^2*r2./s(1:end))./(wsync*((rth+r2./s(1:end)).^2+(xth+x2)^2));
    
wm=(1-s)*wsync;
if(get(handles.pin,'Value')==1)
    yf=1/(j*xm)+1./(r2./s+j*x2);
    zf=1./yf;
    ip=vp./(r1+j*x1+zf);
    pin=3*vp.*abs(ip).*cos(angle(ip));
    axes(handles.axes1);
    plot(nm,pin);
    xlabel('Mechanical Speed(rev/min)');
end
if(get(handles.pc,'Value')==1)
    
    pconv=t_ind.*wm;
    axes(handles.axes2);
    plot(nm,pconv);
    xlabel('Mechanical Speed(rev/min)');
end
if(get(handles.po,'Value')==1)
    
    pconv=t_ind.*wm;
    po=pconv-pcore-pfric-pmisc;
    for i=1:length(po)
        if po(i)<0
            po(i)=0;
        end
    end
    axes(handles.axes4);
    plot(nm,po);
    xlabel('Mechanical Power(rev/min)');
end
if(get(handles.eff,'Value')==1)
    pconv=t_ind.*wm;
    po=pconv-pcore-pfric-pmisc;
    for i=1:length(po)
        if po(i)<0
            po(i)=0;
        end
    end
    yf=1/(j*xm)+1./(r2./s+j*x2);
    zf=1./yf;
    ip=vp./(r1+j*x1+zf);
    pin=3*vp.*abs(ip).*cos(angle(ip));
    axes(handles.axes5);
    eff=(po./pin)*100;
    plot(nm,eff);
    xlabel('Mechanical Speed(rev/min)');
end
% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --- Executes on button press in po.
set(handles.r1,'String','');
set(handles.x1,'String','');
set(handles.r2,'String','');
set(handles.pfw,'String','');
set(handles.x2,'String','');
set(handles.pmisc,'String','');
set(handles.xm,'String','');
set(handles.vl,'String','');
set(handles.f,'String','');
set(handles.p,'String','');
set(handles.pcore,'String','');
set(handles.pc,'Value',0);
set(handles.pin,'Value',0);
set(handles.po,'Value',0);
set(handles.eff,'Value',0);

axes(handles.axes1);
cla reset;
axes(handles.axes2);
cla reset;
axes(handles.axes4);
cla reset;
axes(handles.axes5);
cla reset;
function po_Callback(hObject, eventdata, handles)
% hObject    handle to po (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of po
if(get(handles.po,'Value')==0);
    axes(handles.axes4);
    cla reset;
end

% --- Executes on button press in pin.
function pin_Callback(hObject, eventdata, handles)
% hObject    handle to pin (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of pin
if(get(handles.pin,'Value')==0);
    axes(handles.axes1);
    cla reset;
end

% --- Executes on button press in eff.
function eff_Callback(hObject, eventdata, handles)
% hObject    handle to eff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of eff
if(get(handles.eff,'Value')==0);
    axes(handles.axes5);
    cla reset;
end


function r1_Callback(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of r1 as text
%        str2double(get(hObject,'String')) returns contents of r1 as a double


% --- Executes during object creation, after setting all properties.
function r1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function r2_Callback(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of r2 as text
%        str2double(get(hObject,'String')) returns contents of r2 as a double


% --- Executes during object creation, after setting all properties.
function r2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function xm_Callback(hObject, eventdata, handles)
% hObject    handle to xm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of xm as text
%        str2double(get(hObject,'String')) returns contents of xm as a double


% --- Executes during object creation, after setting all properties.
function xm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x1_Callback(hObject, eventdata, handles)
% hObject    handle to x1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x1 as text
%        str2double(get(hObject,'String')) returns contents of x1 as a double


% --- Executes during object creation, after setting all properties.
function x1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x2_Callback(hObject, eventdata, handles)
% hObject    handle to x2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x2 as text
%        str2double(get(hObject,'String')) returns contents of x2 as a double


% --- Executes during object creation, after setting all properties.
function x2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vl_Callback(hObject, eventdata, handles)
% hObject    handle to vl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vl as text
%        str2double(get(hObject,'String')) returns contents of vl as a double


% --- Executes during object creation, after setting all properties.
function vl_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function f_Callback(hObject, eventdata, handles)
% hObject    handle to f (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of f as text
%        str2double(get(hObject,'String')) returns contents of f as a double


% --- Executes during object creation, after setting all properties.
function f_CreateFcn(hObject, eventdata, handles)
% hObject    handle to f (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function p_Callback(hObject, eventdata, handles)
% hObject    handle to p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of p as text
%        str2double(get(hObject,'String')) returns contents of p as a double


% --- Executes during object creation, after setting all properties.
function p_CreateFcn(hObject, eventdata, handles)
% hObject    handle to p (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pmisc_Callback(hObject, eventdata, handles)
% hObject    handle to pmisc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pmisc as text
%        str2double(get(hObject,'String')) returns contents of pmisc as a double


% --- Executes during object creation, after setting all properties.
function pmisc_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pmisc (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pfw_Callback(hObject, eventdata, handles)
% hObject    handle to pfw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pfw as text
%        str2double(get(hObject,'String')) returns contents of pfw as a double


% --- Executes during object creation, after setting all properties.
function pfw_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pfw (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pcore_Callback(hObject, eventdata, handles)
% hObject    handle to pcore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pcore as text
%        str2double(get(hObject,'String')) returns contents of pcore as a double


% --- Executes during object creation, after setting all properties.
function pcore_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pcore (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
