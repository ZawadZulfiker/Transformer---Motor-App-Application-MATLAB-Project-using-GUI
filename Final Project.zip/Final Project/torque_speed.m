function varargout = torque_speed(varargin)
% TORQUE_SPEED MATLAB code for torque_speed.fig
%      TORQUE_SPEED, by itself, creates a new TORQUE_SPEED or raises the existing
%      singleton*.
%
%      H = TORQUE_SPEED returns the handle to a new TORQUE_SPEED or the handle to
%      the existing singleton*.
%
%      TORQUE_SPEED('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in TORQUE_SPEED.M with the given input arguments.
%
%      TORQUE_SPEED('Property','Value',...) creates a new TORQUE_SPEED or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before torque_speed_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to torque_speed_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help torque_speed

% Last Modified by GUIDE v2.5 15-Aug-2019 03:53:45

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @torque_speed_OpeningFcn, ...
                   'gui_OutputFcn',  @torque_speed_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before torque_speed is made visible.
function torque_speed_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to torque_speed (see VARARGIN)
clc;

% Choose default command line output for torque_speed
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes torque_speed wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = torque_speed_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function edit9_Callback(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit9 as text
%        str2double(get(hObject,'String')) returns contents of edit9 as a double


% --- Executes during object creation, after setting all properties.
function edit9_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in pushbutton5.
function pushbutton5_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.r1,'String','');
set(handles.x1,'String','');
set(handles.r2,'String','');
set(handles.x2,'String','');
set(handles.xm,'String','');
set(handles.vp,'String','');
set(handles.sfreq,'String','');
set(handles.sp,'String','');
set(handles.valr2s,'String','');
flag=get(handles.r2s,'Min');
set(handles.r2s,'Value',flag);
axes(handles.axes1);
cla reset;

% --- Executes on button press in pushbutton7.
function pushbutton7_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton7 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes1);

scr1=str2double(get(handles.r1,'String'));
scr2=str2double(get(handles.r2,'String'));
scx1=str2double(get(handles.x1,'String'));
scx2=str2double(get(handles.x2,'String'));

scxm=str2double(get(handles.xm,'String'));
svl=str2double(get(handles.vp,'String'));
sf=str2double(get(handles.sfreq,'String'));
spole=str2double(get(handles.sp,'String'));

s=0:0.01:1;
s(1)=0.001;

svp=svl/sqrt(3);

vth=svp*(scxm/sqrt(scr1^2+(scx1+scxm)^2));
zth=(j*scxm*(scr1+j*scx1))/(scr1+j*(scx1+scxm));
rth=real(zth);
xth=imag(zth);

nsync=(120*sf)/spole;
wsync=(2*pi*nsync)/60;

nm=(1-s)*nsync;
set(handles.r2s,'Value',scr2);
set(handles.r2s,'Min',scr2/4);
set(handles.r2s,'Max',scr2*4);
scr2n=get(handles.r2s,'Value');
set(handles.valr2s,'String',num2str(scr2n));
t_ind=zeros(1,length(s));
t_ind(1:end)=(3*vth^2*scr2n./s(1:end))./(wsync*((rth+scr2n./s(1:end)).^2+(xth+scx2)^2));

plot(nm,t_ind);
xlabel('Mechanical Speed(rev/min)');
ylabel('Induced torque(Nm)');
% --- Executes on button press in pushbutton8.
function pushbutton8_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton8 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axes(handles.axes4);

dcr1=str2double(get(handles.dr1,'String'));
dcr2i=str2double(get(handles.dr2i,'String'));
dcr2o=str2double(get(handles.dr2o,'String'));
dcx1=str2double(get(handles.dx1,'String'));
dcx2i=str2double(get(handles.dx2i,'String'));
dcx2o=str2double(get(handles.dx2o,'String'));

dcxm=str2double(get(handles.dxm,'String'));
dvl=str2double(get(handles.vpd,'String'));
df=str2double(get(handles.dfreq,'String'));
dpole=str2double(get(handles.dp,'String'));

s=0:0.01:1;
s(1)=0.001;

dvp=dvl/sqrt(3);

vth=dvp*(dcxm/sqrt(dcr1^2+(dcx1+dcxm)^2));
zth=(j*dcxm*(dcr1+j*dcx1))/(dcr1+j*(dcx1+dcxm));
rth=real(zth);
xth=imag(zth);

nsync=(120*df)/dpole;
wsync=(2*pi*nsync)/60;
nm=(1-s)*nsync;

t_ind=zeros(1,length(s));

dy=1./(dcr2i+j.*s*dcx2i)+1./(dcr2o+j.*s*dcx2o);
dz=1./dy;
dr=real(dz);
dx=imag(dz);

t_ind(1:end)=(3*vth.^2*dr./s(1:end))./(wsync*((rth+dr./s(1:end)).^2+(xth+dx).^2));

plot(nm,t_ind);
xlabel('Mechanical Speed(rev/min)');
ylabel('Induced torque(Nm)');

% --- Executes on button press in pushbutton9.
function pushbutton9_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton9 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.dr1,'String','');
set(handles.dx1,'String','');
set(handles.dr2i,'String','');
set(handles.dr2o,'String','');
set(handles.dx2i,'String','');
set(handles.dx2o,'String','');
set(handles.dxm,'String','');
set(handles.vpd,'String','');
set(handles.dfreq,'String','');
set(handles.dp,'String','');

axes(handles.axes4);
cla reset;


function dr1_Callback(hObject, eventdata, handles)
% hObject    handle to dr1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dr1 as text
%        str2double(get(hObject,'String')) returns contents of dr1 as a double


% --- Executes during object creation, after setting all properties.
function dr1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dr1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dr2i_Callback(hObject, eventdata, handles)
% hObject    handle to dr2i (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dr2i as text
%        str2double(get(hObject,'String')) returns contents of dr2i as a double


% --- Executes during object creation, after setting all properties.
function dr2i_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dr2i (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dx2i_Callback(hObject, eventdata, handles)
% hObject    handle to dx2i (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dx2i as text
%        str2double(get(hObject,'String')) returns contents of dx2i as a double


% --- Executes during object creation, after setting all properties.
function dx2i_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dx2i (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dr2o_Callback(hObject, eventdata, handles)
% hObject    handle to dr2o (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dr2o as text
%        str2double(get(hObject,'String')) returns contents of dr2o as a double


% --- Executes during object creation, after setting all properties.
function dr2o_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dr2o (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dx2o_Callback(hObject, eventdata, handles)
% hObject    handle to dx2o (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dx2o as text
%        str2double(get(hObject,'String')) returns contents of dx2o as a double


% --- Executes during object creation, after setting all properties.
function dx2o_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dx2o (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dxm_Callback(hObject, eventdata, handles)
% hObject    handle to dxm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dxm as text
%        str2double(get(hObject,'String')) returns contents of dxm as a double


% --- Executes during object creation, after setting all properties.
function dxm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dxm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dx1_Callback(hObject, eventdata, handles)
% hObject    handle to dx1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dx1 as text
%        str2double(get(hObject,'String')) returns contents of dx1 as a double


% --- Executes during object creation, after setting all properties.
function dx1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dx1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function r1_Callback(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of r1 as text
%        str2double(get(hObject,'String')) returns contents of r1 as a double


% --- Executes during object creation, after setting all properties.
function r1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to r1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x1_Callback(hObject, eventdata, handles)
% hObject    handle to x1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x1 as text
%        str2double(get(hObject,'String')) returns contents of x1 as a double


% --- Executes during object creation, after setting all properties.
function x1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function r2_Callback(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of r2 as text
%        str2double(get(hObject,'String')) returns contents of r2 as a double


% --- Executes during object creation, after setting all properties.
function r2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to r2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function xm_Callback(hObject, eventdata, handles)
% hObject    handle to xm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of xm as text
%        str2double(get(hObject,'String')) returns contents of xm as a double


% --- Executes during object creation, after setting all properties.
function xm_CreateFcn(hObject, eventdata, handles)
% hObject    handle to xm (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function x2_Callback(hObject, eventdata, handles)
% hObject    handle to x2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of x2 as text
%        str2double(get(hObject,'String')) returns contents of x2 as a double


% --- Executes during object creation, after setting all properties.
function x2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to x2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vpd_Callback(hObject, eventdata, handles)
% hObject    handle to vpd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vpd as text
%        str2double(get(hObject,'String')) returns contents of vpd as a double


% --- Executes during object creation, after setting all properties.
function vpd_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vpd (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function vp_Callback(hObject, eventdata, handles)
% hObject    handle to vp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of vp as text
%        str2double(get(hObject,'String')) returns contents of vp as a double


% --- Executes during object creation, after setting all properties.
function vp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to vp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dfreq_Callback(hObject, eventdata, handles)
% hObject    handle to dfreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dfreq as text
%        str2double(get(hObject,'String')) returns contents of dfreq as a double


% --- Executes during object creation, after setting all properties.
function dfreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dfreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sfreq_Callback(hObject, eventdata, handles)
% hObject    handle to sfreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sfreq as text
%        str2double(get(hObject,'String')) returns contents of sfreq as a double


% --- Executes during object creation, after setting all properties.
function sfreq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sfreq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function dp_Callback(hObject, eventdata, handles)
% hObject    handle to dp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of dp as text
%        str2double(get(hObject,'String')) returns contents of dp as a double


% --- Executes during object creation, after setting all properties.
function dp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function sp_Callback(hObject, eventdata, handles)
% hObject    handle to sp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sp as text
%        str2double(get(hObject,'String')) returns contents of sp as a double


% --- Executes during object creation, after setting all properties.
function sp_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sp (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function r2s_Callback(hObject, eventdata, handles)
% hObject    handle to r2s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'Value') returns position of slider
%        get(hObject,'Min') and get(hObject,'Max') to determine range of slider


% --- Executes during object creation, after setting all properties.
axes(handles.axes1);

scr1=str2double(get(handles.r1,'String'));
scr2=str2double(get(handles.r2,'String'));
scx1=str2double(get(handles.x1,'String'));
scx2=str2double(get(handles.x2,'String'));

scxm=str2double(get(handles.xm,'String'));
svl=str2double(get(handles.vp,'String'));
sf=str2double(get(handles.sfreq,'String'));
spole=str2double(get(handles.sp,'String'));

s=0:0.01:1;
s(1)=0.001;

svp=svl/sqrt(3);

vth=svp*(scxm/sqrt(scr1^2+(scx1+scxm)^2));
zth=(j*scxm*(scr1+j*scx1))/(scr1+j*(scx1+scxm));
rth=real(zth);
xth=imag(zth);

nsync=(120*sf)/spole;
wsync=(2*pi*nsync)/60;

nm=(1-s)*nsync;

scr2n=get(handles.r2s,'Value');
set(handles.valr2s,'String',num2str(scr2n));
t_ind=zeros(1,length(s));
t_ind(1:end)=(3*vth^2*scr2n./s(1:end))./(wsync*((rth+scr2n./s(1:end)).^2+(xth+scx2)^2));

plot(nm,t_ind);
xlabel('Mechanical Speed(rev/min)');
ylabel('Induced torque(Nm)');
function r2s_CreateFcn(hObject, eventdata, handles)
% hObject    handle to r2s (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


% --- Executes on slider movement.
