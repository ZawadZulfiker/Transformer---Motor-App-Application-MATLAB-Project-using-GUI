function p=short_circuit(vsc,isc,psc)
thetaoc=acos(psc/(vsc*isc));
ze=(vsc/isc)*exp(i*thetaoc);
req=(real(ze));
xeq=(imag(ze));
p=[req xeq];
end